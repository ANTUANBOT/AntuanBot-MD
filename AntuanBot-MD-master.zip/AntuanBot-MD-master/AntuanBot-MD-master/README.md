<p align="center"> 
<a href="https://github.com/GataNina-Li"><img src="http://readme-typing-svg.herokuapp.com?font=mono&size=17&duration=4000&color=F7B11B&center=falso&vCenter=falso&lines=GataBot-MD++%F0%9F%90%88;Gracias+por+visitar+este+repositorio.+%F0%9F%92%96" height="90px"></a> 
</p>
 
<p align="center">
<img src="https://i.imgur.com/kd8sus3.jpeg" alt="GataBot-MD" width="800"/>
  
> Antes de usar este repositorio, visita la **[Política de AntuanBot. 😼](https://github.com/ANTUANBOT/AntuanBot-MD/blob/master/terms.md)** 
</p>

<p align="center">
<a href="#"><img title="AntuanBot-MD" src="https://img.shields.io/badge/SI TE AGRADA EL REPOSITORIO APOYAME CON UNA 🌟 ¡GRACIAS! -red?colorA=%255ff0000&colorB=%23017e40&style=for-the-badge"></a> 
<img src="https://i.pinimg.com/originals/d4/3c/90/d43c902873d4db8c85974dfd0798030b.gif" height="28px">
</p>  

<p align="center">
<a href="#"><img title="AntuanBot-MD" src="https://img.shields.io/badge/LEA TODO EL README-red?colorA=%F77F48FF&colorB=%F77F48FF&style=for-the-badge"></a> 
<a href="#"><img title="AntuanBot-MD" src="https://img.shields.io/badge/COMPATIBLE CON LA VERSIÓN MULTI DISPOSITIVOS DE WHATSAPP-red?colorA=%F77F48FF&colorB=%F77F48FF&style=for-the-badge"></a>
</p>

<p align="center">   
<a href="https://github.com/ANTUANBOT/AntuanBot-MD/watchers"><img title="Watchers" src="https://img.shields.io/github/watchers/GataNina-Li/GataBot-MD?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/ANTUANBOT/AntuanBot-MD/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/GataNina-Li/GataBot-MD?label=Stars&color=yellow&style=flat-square"></a>
</p>

<div align="center">
  
[![Gmail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:centerantuanbot@gmail.com)
[![Support](https://img.shields.io/badge/Support-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/SoporteAntuanBot)
[![WhatsApp](https://img.shields.io/badge/STAFF-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/+51947311549)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://instagram.com/antuan_dios)
</div>

### 👇 `Todas las cuentas están aquí!!`
[![Enlaces](https://img.shields.io/badge/GataBot_Accounts-000000%7D?style=for-the-badge&logo=biolink&logoColor=white)](https://www.atom.bio/gatabot/)

-----
# 📍 Atajos del README

| TEMA | DESCRIPCIÓN | ATAJO |
|------|-------------|-------|
| **TERMUX** | ***INSTALACIÓN AUTOMÁTICA*** |[ver](https://github.com/ANTUANBOT/AntuanBot-MD/tree/master?tab=readme-ov-file#-opci%C3%B3n-1-instalaci%C3%B3n-autom%C3%A1tica-) |
| **TERMUX** | ***INSTALACIÓN MANUAL*** |[ver](https://github.com/ANTUANBOT/AntuanBot-MD/#-opción-2-instalación-manual-por-termux---github) |
| **TERMUX** | ***INSTALACIÓN POR ARCHIVOS*** |[ver](https://github.com/ANTUANBOT/AntuanBot-MD/#-opción-3-instalación-por-termux---archivos) |
| **TERMUX 24/7** | ***COMANDOS*** |[ver](https://github.com/ANTUANBOT/AntuanBot-MD/#-usar-antuanbot-247-en-termux) |
| **TERMUX UPDATE** | ***COMANDOS PARA ACTUALIZAR GATABOT*** |[ver](https://github.com/ANTUANBOT/AntuanBot-MD/#-actualizar-antuanbot) |
-----
### 🌟 (OPCIÓN 1) INSTALACIÓN AUTOMÁTICA 🫰
[![blog](https://img.shields.io/badge/Instalacion-Automatica-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://youtube.com/shorts/PESW8LXXlOI?feature=share)
> **Note** Comandos para instalar de forma automática en Termux  
```bash
termux-setup-storage
```
```bash
apt update -y && yes | apt upgrade && pkg install -y bash wget mpv && wget -O - https://raw.githubusercontent.com/GataNina-Li/GataBot-MD/master/gata.sh | bash
```
```js
// PERSONALIZAR INSTALACIÓN AUTOMÁTICA (En caso de una Bifurcación)
// Parámetros editables

```js
//LÍNEAS A MODIFICAR
205 --> "git clone https://github.com/[user]/[repositorio].git"
//Ejemplo: git clone https://github.com/ANTUANBOT/AntuanBot-MD.git

209 --> "cd [repositorio]"
//Ejemplo: cd AntuanBot-MD

//Una vez hecho estos cambios ejecute los nuevos comandos en Termux
```
-----
### 🪄 (OPCIÓN 2) INSTALACIÓN MANUAL POR TERMUX - GITHUB 
> **Note** Comandos para instalar de forma manual
```bash
termux-setup-storage
```
```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```
```bash
git clone https://github.com/GataNina-Li/GataBot-MD && cd GataBot-MD
```
```bash
yarn install && npm install
```
```bash
npm start
```
> **Warning** Si aparece (Y/I/N/O/D/Z) [default=N] ? use la letra "y" + "ENTER" para continuar con la instalación 
------------------
### 📁 (OPCIÓN 3) INSTALACIÓN POR TERMUX - ARCHIVOS
> **Note** Descargué y Descomprime
### [`AntuanBot-MD ~ Archivos`](https://github.com/ANTUANBOT/AntuanBot-MD/archive/refs/heads/master.zip)
[![blog](https://img.shields.io/badge/Termux-AntuanBotMD-FF0000?style=for-the-badge&logo=youtube&logoColor=white)
](https://youtu.be/UcWlyQ8u5HE)
```bash
termux-setup-storage
```
```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```
```bash
cd storage/downloads/AntuanBot-MD-master/AntuanBot-MD-master 
```
```bash
yarn install
```
```bash
npm install
```
```bash
npm start
```
* #### APLICACIÓN RECOMENDADA PARA [`DESCOMPRIMIR`](https://play.google.com/store/apps/details?id=com.rarlab.rar)
* #### APLICACIÓN RECOMENDADA PARA EDITAR [`NÚMERO DE OWNER`](https://play.google.com/store/apps/details?id=com.rhmsoft.code)
> **Note** Guardar los archivos en la ubicación: storage/downloads/AntuanBot-MD-master/AntuanBot-MD-master   
----
### 🚀 USAR ANTUANBOT 24/7 EN TERMUX 
> Ejecutar estos comandos dentro de la carpeta GataBot-MD
```bash
termux-wake-lock && npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs 
``` 
#### ⬇️ Opciones Disponibles
> **Warning** Esto eliminará todo el historial que hayas establecido con PM2:
```bash 
pm2 delete index
``` 
> Si tienes cerrado Termux y quiere ver de nuevo la ejecución use:
```bash 
pm2 logs 
``` 
> Si desea detener la ejecución de Termux use:
```bash 
pm2 stop index
``` 
> Si desea iniciar de nuevo la ejecución de Termux use:
```bash 
pm2 start index
``` 
---- 
### `🟢 ACTIVAR EN CASO DE DETENERSE EN TERMUX`
> **Note** Si despues que ya instalastes tu bot y termux te salta en blanco, se fue tu internet o reiniciaste tu celular, solo realizaras estos pasos :
```bash
cd
```
```bash
cd AntuanBot-MD
```
```bash
npm start
```
----
### `🔵 OBTENER OTRO CODIGO QR EN TERMUX`
> **Warning** deten el bot, haz click en el símbolo (ctrl) [default=z] usar la letra "z" + "ENTER" hasta que salga algo verdes similar a : AntuanBot-MD $
> escribe los siguientes comando uno x uno :
```bash 
cd AntuanBot-MD
```
```bash
rm -rf AntuanBotSession
```
```bash
npm start
```
----
### 😼 ACTUALIZAR ANTUANBOT
> **Note** Comandos para actualizar AntuanBot-MD de forma automática
```bash
grep -q 'bash\|wget' <(dpkg -l) || apt install -y bash wget && wget -O - https://raw.githubusercontent.com/ANTUANBOT/AntuanBot-MD/master/update.sh | bash 
```
#### Para que no pierda su progreso en AntuanBot, estos comandos realizarán un respaldo de su `database.json` y se agregará a la versión más reciente.
> **Warning** Estos comandos solo funcionan para TERMUX, REPLIT, LINUX                            
----
### 💠 [`IDIOMAS DISPONIBLES PARA ANTUANBOT`](https://github.com/GataNina-Li/GataBot-MD/blob/master/config.js) 
#### 🌐 Español  
- [x] Ejemplo <details><summary>Idioma</summary><img src="https://i.imgur.com/ZTwOGkT.jpg"></details>
----
### 🌟 CREADORA 
[![AntuanBot-MD](https://github.com/ANTUANBOT.png?size=100)](https://github.com/ANTUANBOT) 
> Copyright (c) 2024 **[AntuanBot-MD](https://github.com/ANTUANBOT/AntuanBot-MD/blob/master/LICENSE)**.
