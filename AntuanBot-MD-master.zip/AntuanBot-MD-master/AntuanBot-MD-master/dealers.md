### Aquí puedes verificar los distribuidores autorizados.
#### ✅ = Distribuidor en curso.
#### ⚪ = Sin información.
 
| USUARIO          |   CÓDIGO                | CONTACTO    | ESTADO
| ------------     | ------------            | ------------| ------------
| [**Richetti123**](https://github.com/Richetti123)        | `KmZxVE5lIUVvrkqLd8EYJlC9G` | `IG: @richetti_123` | ✅
| ⚪        | ⚪               |  ⚪ | ⚪

