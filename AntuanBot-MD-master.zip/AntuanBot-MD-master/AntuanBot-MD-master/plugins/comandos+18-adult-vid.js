import fetch from 'node-fetch'
let handler = async (m, { conn, command, usedPrefix }) => {
let frep = { contextInfo: { externalAdReply: {title: wm, body: lenguajeGB.smsCont18PornP2(), sourceUrl: redesMenu.getRandom(), thumbnail: await(await fetch(img16)).buffer() }}}
let user = global.db.data.users[m.sender]
let enlace = await pornovid[Math.floor(Math.random() * pornovid.length)] 
let enlace1 = await pornovid2[Math.floor(Math.random() * pornovid2.length)] 
let enlace2 = await pornovidlesbi[Math.floor(Math.random() * pornovidlesbi.length)] 
let enlace3 = await pornovidgay[Math.floor(Math.random() * pornovidgay.length)] 
let enlace4 = await pornovidbisexual[Math.floor(Math.random() * pornovidbisexual.length)] 
let enlace5 = await pornovidrandom[Math.floor(Math.random() * pornovidrandom.length)] 

if (!db.data.chats[m.chat].modohorny && m.isGroup) throw `${lenguajeGB['smsContAdult']()}`
try{ 
switch (command) {  
case "pornovid": case "nsfwvid":    
//await conn.sendFile(m.chat, enlace, null, `${lenguajeGB['smsCont18Porn']()}\n${lenguajeGB['smsBotonM7']()} » ${user.premiumTime > 0 ? '✅' : '❌'}`, null, null, {viewOnce: true}, frep, m)
await conn.sendFile(m.chat, enlace, null, `${lenguajeGB['smsCont18Porn']()}\n${lenguajeGB['smsBotonM7']()} » ${user.premiumTime > 0 ? '✅' : '❌'}`, m, null, {viewOnce: true})
//await conn.sendButton(m.chat, lenguajeGB.smsCont18PornP(), `*_${lenguajeGB['smsBotonM7']()}_* » ${user.premiumTime > 0 ? '✅' : '❌'}\n` + wm + ` : *${command[0].toUpperCase() + command.substring(1)}*`, enlace, [[lenguajeGB.smsSigPrem(), `${usedPrefix + command}`], [`🥵 ${lenguajeGB.lenguaje() == 'es' ? 'porno vid 2' : 'nsfw vid 2'} 🥵`.toUpperCase(), `${usedPrefix}${lenguajeGB.lenguaje() == 'es' ? 'pornovid2' : 'nsfwvid2'}`]], m, frep) 
break  
    
case "pornovid2": case "nsfwvid2":    
await conn.sendFile(m.chat, enlace1, null, `${lenguajeGB['smsCont18Porn']()}\n${lenguajeGB['smsBotonM7']()} » ${user.premiumTime > 0 ? '✅' : '❌'}`, m, null, {viewOnce: true})
//await conn.sendButton(m.chat, lenguajeGB.smsCont18PornP(), `*_${lenguajeGB['smsBotonM7']()}_* » ${user.premiumTime > 0 ? '✅' : '❌'}\n` + wm + ` : *${command[0].toUpperCase() + command.substring(1)}*`, enlace1, [[lenguajeGB.smsSigPrem(), `${usedPrefix + command}`], [`🥵 ${lenguajeGB.lenguaje() == 'es' ? 'porno vid random' : 'nsfw vid random'} 🥵`.toUpperCase(), `${usedPrefix}${lenguajeGB.lenguaje() == 'es' ? 'pornovidrandom' : 'nsfwvidrandom'}`]], m, frep) 
break 

case "pornovidlesbi": case "nsfwvidlesbi":       
await conn.sendFile(m.chat, enlace2, null, `${lenguajeGB['smsCont18Porn']()}\n${lenguajeGB['smsBotonM7']()} » ${user.premiumTime > 0 ? '✅' : '❌'}`, m, null, {viewOnce: true})
//await conn.sendButton(m.chat, lenguajeGB.smsCont18PornP(), `*_${lenguajeGB['smsBotonM7']()}_* » ${user.premiumTime > 0 ? '✅' : '❌'}\n` + wm + ` : *${command[0].toUpperCase() + command.substring(1)}*`, enlace2, [[lenguajeGB.smsSigPrem(), `${usedPrefix + command}`]], m, frep)  
break 

case "pornovidgay": case "nsfwvidgay":       
await conn.sendFile(m.chat, enlace3, null, `${lenguajeGB['smsCont18Porn']()}\n${lenguajeGB['smsBotonM7']()} » ${user.premiumTime > 0 ? '✅' : '❌'}`, m, null, {viewOnce: true})
//await conn.sendButton(m.chat, lenguajeGB.smsCont18PornP(), `*_${lenguajeGB['smsBotonM7']()}_* » ${user.premiumTime > 0 ? '✅' : '❌'}\n` + wm + ` : *${command[0].toUpperCase() + command.substring(1)}*`, enlace3, [[lenguajeGB.smsSigPrem(), `${usedPrefix + command}`]], m, frep)  
break 
    
case "pornovidbisexual": case "nsfwvidbisexual":       
await conn.sendFile(m.chat, enlace4, null, `${lenguajeGB['smsCont18Porn']()}\n${lenguajeGB['smsBotonM7']()} » ${user.premiumTime > 0 ? '✅' : '❌'}`, m, null, {viewOnce: true})
//await conn.sendButton(m.chat, lenguajeGB.smsCont18PornP(), `*_${lenguajeGB['smsBotonM7']()}_* » ${user.premiumTime > 0 ? '✅' : '❌'}\n` + wm + ` : *${command[0].toUpperCase() + command.substring(1)}*`, enlace4, [[lenguajeGB.smsSigPrem(), `${usedPrefix + command}`]], m, frep)  
break 
    
case "pornovidrandom": case "nsfwvidrandom":       
await conn.sendFile(m.chat, enlace5, null, `${lenguajeGB['smsCont18Porn']()}\n${lenguajeGB['smsBotonM7']()} » ${user.premiumTime > 0 ? '✅' : '❌'}`, m, null, {viewOnce: true})
//await conn.sendButton(m.chat, lenguajeGB.smsCont18PornP(), `*_${lenguajeGB['smsBotonM7']()}_* » ${user.premiumTime > 0 ? '✅' : '❌'}\n` + wm + ` : *${command[0].toUpperCase() + command.substring(1)}*`, enlace5, [[lenguajeGB.smsSigPrem(), `${usedPrefix + command}`], [`🥵 ${lenguajeGB.lenguaje() == 'es' ? 'porno vid' : 'nsfw vid'} 🥵`.toUpperCase(), `${usedPrefix}${lenguajeGB.lenguaje() == 'es' ? 'pornovid' : 'nsfwvid'}`]], m, frep)  
break 
        
}} catch (e) {
await conn.reply(m.chat, `${lenguajeGB['smsMalError3']()}#report ${lenguajeGB['smsMensError2']()} ${usedPrefix + command}\n\n${wm}`, fkontak, m)
console.log(`❗❗ ${lenguajeGB['smsMensError2']()} ${usedPrefix + command} ❗❗`)
console.log(e)}
}
handler.command = ['pornovid', 'nsfwvid', 'pornovid2', 'nsfwvid2', 'pornovidlesbi', 'nsfwvidlesbi', 'pornovidgay', 'nsfwvidgay', 'pornovidbisexual', 'nsfwvidbisexual', 'pornovidrandom', 'nsfwvidrandom']
handler.premium = true
handler.register = true
export default handler


global.pornovid = [
"https://l.top4top.io/m_2235dduf01.mp4",
"https://a.top4top.io/m_2235268m61.mp4",
"https://b.top4top.io/m_2235k7hze2.mp4",
"https://c.top4top.io/m_2235lxohb3.mp4",
"https://d.top4top.io/m_2235jwd2e4.mp4",
"https://e.top4top.io/m_2235h5b1z5.mp4",
"https://f.top4top.io/m_2235gihcu6.mp4",
"https://l.top4top.io/m_2235dp7m41.mp4",
"https://a.top4top.io/m_2235zxue82.mp4",
"https://b.top4top.io/m_2235m3bhf3.mp4",
"https://c.top4top.io/m_2235vjyio4.mp4",
"https://d.top4top.io/m_2235m9tdu5.mp4",
"https://e.top4top.io/m_2235y2kon6.mp4",
"https://f.top4top.io/m_2235rhid57.mp4",
"https://g.top4top.io/m_2235zgsqf8.mp4",
"https://i.top4top.io/m_2235drxxg10.mp4",
"https://d.top4top.io/m_2235fzynm1.mp4",    
"https://e.top4top.io/m_22354t3zk2.mp4",
"https://f.top4top.io/m_2235gyxgh3.mp4",
"https://g.top4top.io/m_22357cmft4.mp4", 
"https://i.top4top.io/m_2235mcizm6.mp4",
"https://j.top4top.io/m_2235gwsn17.mp4",
"https://k.top4top.io/m_2235gzzjc8.mp4",
"https://a.top4top.io/m_2235l9y1310.mp4",  
"https://l.top4top.io/m_2235r1opz1.mp4",    
"https://a.top4top.io/m_22358cuuu2.mp4",
"https://b.top4top.io/m_22350c9br3.mp4",
"https://c.top4top.io/m_22355p2js4.mp4",  
"https://d.top4top.io/m_2235lv7415.mp4",
"https://e.top4top.io/m_2235q8z3f6.mp4",     
"https://b.top4top.io/m_22358oas31.mp4",
"https://c.top4top.io/m_2235xg7o62.mp4",
"https://d.top4top.io/m_2235ut91p3.mp4",
"https://e.top4top.io/m_22352ktoj4.mp4",
"https://f.top4top.io/m_2235hcqj65.mp4",
"https://g.top4top.io/m_2235j81s76.mp4"]


global.pornovid2 = [
"https://l.top4top.io/m_22572kvnt0.mp4",
"https://a.top4top.io/m_22741bntt0.mp4",
"https://g.top4top.io/m_2274ss8270.mp4",
"https://h.top4top.io/m_22746h8370.mp4",
"https://c.top4top.io/m_2274k1olx1.mp4",
"https://k.top4top.io/m_2274iu8ph1.mp4",
"https://c.top4top.io/m_2274813w23.mp4",
"https://g.top4top.io/m_2274qzr5b5.mp4",
"https://k.top4top.io/m_2274znr525.mp4",
"https://j.top4top.io/m_22744mccx0.mp4",
"https://g.top4top.io/m_2274dkhny3.mp4",
"https://i.top4top.io/m_2257a87ov0.mp4", 
"https://k.top4top.io/m_2257xoco60.mp4",
"https://i.top4top.io/m_2257uqopw1.mp4",
"https://b.top4top.io/m_2257p8fdg0.mp4",
"https://c.top4top.io/m_2257ju33j0.mp4",
"https://a.top4top.io/m_2257showp0.mp4",
"https://b.top4top.io/m_22578syiy0.mp4",
"https://a.top4top.io/m_22576ni620.mp4",
"https://f.top4top.io/m_2257f9mcv1.mp4",
"https://e.top4top.io/m_2257efy1t0.mp4",
"https://b.top4top.io/m_2257kc2960.mp4",
"https://b.top4top.io/m_2257oe6hv0.mp4",
"https://h.top4top.io/m_2257zsfo91.mp4",
"https://b.top4top.io/m_2257pugx00.mp4",
"https://i.top4top.io/m_225756xso0.mp4",
"https://h.top4top.io/m_22573rdw80.mp4",
"https://f.top4top.io/m_2235sxi5y1.mp4",
"https://f.top4top.io/m_2257ofv9s0.mp4",
"https://e.top4top.io/m_2257scyvl1.mp4",
"https://e.top4top.io/m_2257di15t0.mp4",
"https://d.top4top.io/m_225754y5s0.mp4",
"https://j.top4top.io/m_22573jxk20.mp4",
"https://d.top4top.io/m_2257puxyo0.mp4",
"https://e.top4top.io/m_2257bb1an0.mp4",
"https://a.top4top.io/m_2257utyrp0.mp4",
"https://b.top4top.io/m_22571xiss0.mp4",
"https://a.top4top.io/m_2257tgfkz0.mp4",
"https://a.top4top.io/m_2263r7okf0.mp4",
"https://g.top4top.io/m_2263l67d60.mp4",
"https://c.top4top.io/m_2263l4udc0.mp4",
"https://c.top4top.io/m_2263ap0rg0.mp4",
"https://a.top4top.io/m_2263lhkvu0.mp4",
"https://l.top4top.io/m_2263hwu9e0.mp4",
"https://g.top4top.io/m_22632ofax0.mp4",
"https://e.top4top.io/m_22636mlov3.mp4",
"https://l.top4top.io/m_22633xw4r0.mp4",
"https://f.top4top.io/m_2263chaub0.mp4",
"https://f.top4top.io/m_2263pljyx0.mp4",
"https://h.top4top.io/m_2263u512n0.mp4",
"https://k.top4top.io/m_22633kkj80.mp4",
"https://e.top4top.io/m_226380tpe0.mp4",
"https://g.top4top.io/m_2263bmdi20.mp4",
"https://j.top4top.io/m_2263ry6570.mp4",
"https://i.top4top.io/m_2263hkobr0.mp4"]



global.pornovidlesbi = [
"https://l.top4top.io/m_2257y4pyl0.mp4",
"https://c.top4top.io/m_2274woesg0.mp4",
"https://k.top4top.io/m_2257pdwjy0.mp4",
"https://a.top4top.io/m_2257qulmx0.mp4",
"https://a.top4top.io/m_2257vxzr62.mp4",
"https://b.top4top.io/m_2257wjmbh3.mp4",
"https://b.top4top.io/m_2257sen2a1.mp4",
"https://c.top4top.io/m_2257hpo9v3.mp4",
"https://e.top4top.io/m_2257pye7u1.mp4",
"https://c.top4top.io/m_2257p7xg14.mp4",
"https://c.top4top.io/m_2257p4v9i3.mp4",
"https://l.top4top.io/m_2257jvkrv3.mp4",
"https://b.top4top.io/m_2257pl7wh1.mp4",
"https://e.top4top.io/m_2257fiwnp2.mp4",
"https://b.top4top.io/m_22578b1nk1.mp4",
"https://k.top4top.io/m_22572gv7q1.mp4",
"https://i.top4top.io/m_2257pu90l2.mp4",
"https://d.top4top.io/m_2257vcwiw3.mp4",
"https://j.top4top.io/m_2258joebc2.mp4",
"https://g.top4top.io/m_2258kvnba4.mp4",
"https://f.top4top.io/m_2258nm8pe1.mp4",
"https://g.top4top.io/m_2258af7bc2.mp4",
"https://l.top4top.io/m_2258f0ci92.mp4",
"https://j.top4top.io/m_2258ehqpb2.mp4",
"https://h.top4top.io/m_2258pckkf3.mp4",
"https://e.top4top.io/m_225857rs20.mp4",
"https://k.top4top.io/m_225863kpa0.mp4",
"https://j.top4top.io/m_2258s6we62.mp4",
"https://i.top4top.io/m_2258if6l13.mp4",
"https://b.top4top.io/m_2258lmd2h1.mp4",
"https://j.top4top.io/m_2258a9oah2.mp4",
"https://i.top4top.io/m_22588w3xh0.mp4",
"https://g.top4top.io/m_225885lm14.mp4",
"https://e.top4top.io/m_2258buxc30.mp4",
"https://e.top4top.io/m_2258fvra62.mp4",
"https://l.top4top.io/m_22588mx7k4.mp4",
"https://g.top4top.io/m_2258zhldg1.mp4"]



global.pornovidgay = [
"https://g.top4top.io/m_2257kulna0.mp4",
"https://k.top4top.io/m_22748dfb90.mp4",
"https://i.top4top.io/m_2274688ut3.mp4",
"https://e.top4top.io/m_2274g8pb05.mp4",
"https://k.top4top.io/m_2274lmhea5.mp4",
"https://e.top4top.io/m_2274h6rw62.mp4",
"https://g.top4top.io/m_2274mouou0.mp4",
"https://l.top4top.io/m_22740lsb50.mp4",
"https://h.top4top.io/m_2274wpa5s4.mp4",
"https://d.top4top.io/m_2274feoh61.mp4",
"https://a.top4top.io/m_2274h40n40.mp4",
"https://b.top4top.io/m_2274twfxf0.mp4",
"https://e.top4top.io/m_2274jjjnz6.mp4",
"https://g.top4top.io/m_2274ibf4k8.mp4",
"https://i.top4top.io/m_22740m5ov0.mp4",
"https://j.top4top.io/m_2274qjlbt1.mp4",
"https://k.top4top.io/m_2274jkgqf4.mp4",
"https://f.top4top.io/m_2274cskme7.mp4",
"https://e.top4top.io/m_2274zh7nx7.mp4",
"https://b.top4top.io/m_2274lwduw0.mp4",
"https://k.top4top.io/m_2274x95hi4.mp4",
"https://j.top4top.io/m_2274smzui0.mp4",
"https://b.top4top.io/m_2257l6p450.mp4",
"https://h.top4top.io/m_2257pvfm60.mp4",
"https://l.top4top.io/m_2257dwqiz4.mp4",
"https://l.top4top.io/m_22570gq4r0.mp4",
"https://e.top4top.io/m_22575tzit0.mp4",
"https://j.top4top.io/m_2257pf8mh0.mp4",
"https://b.top4top.io/m_22573zdwj3.mp4",
"https://h.top4top.io/m_22572j8n84.mp4",
"https://f.top4top.io/m_2257hturm2.mp4",
"https://c.top4top.io/m_2257ler770.mp4",
"https://l.top4top.io/m_2257p6e4y3.mp4",
"https://d.top4top.io/m_2257j8tk80.mp4",
"https://k.top4top.io/m_2257sam501.mp4",
"https://a.top4top.io/m_2258fe4qh0.mp4",
"https://g.top4top.io/m_2258jd95g0.mp4",
"https://b.top4top.io/m_2258o58vk3.mp4",
"https://f.top4top.io/m_2258ovrol3.mp4",
"https://l.top4top.io/m_2258hiid23.mp4",
"https://l.top4top.io/m_2258wcrfr4.mp4",
"https://i.top4top.io/m_2258xvx9e3.mp4",
"https://d.top4top.io/m_2258bhb2y3.mp4",
"https://d.top4top.io/m_2258rmcgc2.mp4", 
"https://l.top4top.io/m_22586l94p5.mp4",
"https://b.top4top.io/m_22581acoi3.mp4",
"https://j.top4top.io/m_2258ktw1f2.mp4",
"https://h.top4top.io/m_2258ltxke2.mp4",
"https://f.top4top.io/m_2258gt7351.mp4",
"https://k.top4top.io/m_2258w87zn5.mp4"]


global.pornovidbisexual = [
"https://k.top4top.io/m_2263d17nb0.mp4",
"https://l.top4top.io/m_2263rs1410.mp4",
"https://g.top4top.io/m_2263qat3w0.mp4",
"https://e.top4top.io/m_2263reat85.mp4",
"https://d.top4top.io/m_2263bdzwa0.mp4",
"https://k.top4top.io/m_22636swzc0.mp4",
"https://l.top4top.io/m_2263h1jc03.mp4",
"https://k.top4top.io/m_2263mh8u04.mp4",
"https://l.top4top.io/m_2263wonsx1.mp4",
"https://f.top4top.io/m_22631d63o0.mp4",
"https://e.top4top.io/m_22630da3s0.mp4",
"https://j.top4top.io/m_2263e0tg90.mp4",
"https://e.top4top.io/m_226338lts5.mp4",
"https://e.top4top.io/m_226307zk80.mp4",
"https://h.top4top.io/m_2263q60k60.mp4",
"https://a.top4top.io/m_2263xdx270.mp4"]


global.pornovidrandom = [
"https://k.top4top.io/m_2277tg6m70.mp4",
"https://d.top4top.io/m_2277t2jeh0.mp4",
"https://c.top4top.io/m_2277wxhle0.mp4",
"https://g.top4top.io/m_22776umn92.mp4",
"https://e.top4top.io/m_22776amjl4.mp4",
"https://h.top4top.io/m_2277ksf281.mp4",
"https://f.top4top.io/m_2277iliie1.mp4",
"https://c.top4top.io/m_2277axzz01.mp4",
"https://c.top4top.io/m_22777p6uz0.mp4",
"https://e.top4top.io/m_22774k28n2.mp4",
"https://l.top4top.io/m_2277dz2zw2.mp4",
"https://b.top4top.io/m_2277uaciz3.mp4",
"https://j.top4top.io/m_2277conhn3.mp4",
"https://k.top4top.io/m_2277dgyml1.mp4",
"https://k.top4top.io/m_2277on1gg2.mp4",
"https://h.top4top.io/m_22774jf141.mp4",
"https://b.top4top.io/m_22774wjs32.mp4",
"https://f.top4top.io/m_2277k9gw00.mp4",
]
