import { es, en } from '../lib/multi-language/_default.js' 
export async function before(m,{ conn }) {
let idioma  = global.db.data.users[m.sender].midLanguage
let MID_AB
  
if (idioma == "es") {
MID_AB = es
} else if (idioma == "en") {
MID_AB = en
} else {
MID_AB = mid || es
}
global.mid = MID_AB	
}
